start xmrig2xdag -c config.json
start xmrig -c config2.json